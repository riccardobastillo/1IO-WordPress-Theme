=== WPI Theme ===
Contributors: Jose, riccardobastillo1
Tags: custom-colors, theme-options, translation-ready, blogfeatured-images, footer-widgets, rtl-language-support, sticky-post, threaded-comments, translation-ready
Requires at least: 4.9.6
Tested up to: WordPress 5.2.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An easly customizable theme focused on the needs of our comunity.

== Description ==
An easly customizable theme focused on the needs of our comunity.

== Changelog ==

= 1.0.0 =
* Released: Initial release
